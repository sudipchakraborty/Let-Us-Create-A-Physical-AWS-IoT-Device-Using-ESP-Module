﻿using System.ComponentModel.Design;

using Tools;

internal class Program
{
   static AWS_MQTT_Client device;
   static int count=0;

    private static void Main(string[] args)
    {
         string iotEndpoint = "............";
         string topic = ".........../accepted";
         string password = "..............";
         device=new AWS_MQTT_Client(iotEndpoint, topic, password);

        device.connect();

        if(device.connected)
        {
            Console.WriteLine("Device connected with AWS ok...");
        }

        while(device.connected)
        {
            Thread.Sleep(1000);
            device.send(count.ToString());
            count++;
        }
         Console.ReadLine();
      
   
    }
}